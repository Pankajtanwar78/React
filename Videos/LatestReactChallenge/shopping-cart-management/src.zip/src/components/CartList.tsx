import {UseCart} from '../context/CartProvider'
import CartItem from './CartItem';

const CartList = () => {

  const cartContext = UseCart();

  return (
    <div style={{marginLeft: '20px',width: 'auto', display: 'flex', padding: '10px', flexDirection: 'column', backgroundColor: 'black', 
      border: '1px solid orange', borderRadius: '10px' }}>
      <div style={{backgroundColor: '#ddd', color: 'black', 
      textAlign: 'center', fontSize: '20px',
      padding: '10px', marginBottom: '10px', border: '1px solid black', borderRadius: '10px'}}>Products in Cart</div>
      {
        cartContext.cartList.map(cart => {
          return <div key={cart.id}>
            <CartItem itemInCart={cart} />
          </div>
        })
      }
    </div>
  )
}

export default CartList