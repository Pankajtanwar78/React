import { UseAuth } from "../context/AuthProvider";
import { UseCart } from "../context/CartProvider";
import { Product } from "../data/initialData"

type ProductItemProp= {
  product: Product;
}

const ProductItem = ({product}: ProductItemProp) => {
  
  const cartContext = UseCart();
  const authContext = UseAuth();

  return (
    <div style={{padding: '10px', color: '#fff', border: '1px solid #fff', borderRadius: '4px', marginBottom: '10px'}}>
      <div style={{marginBottom: '5px', fontWeight: 'bold'}}>
        {product.name}
      </div>
      <div style={{marginBottom: '5px'}}>{product.price}</div>
      <div style={{marginBottom: '5px'}}>{product.description}</div>
      <button onClick={() => {
        if(authContext.authState.isAuthenticate){
          cartContext.dispatch({
            type: 'ADD_TO_CART',
            payload: product
          })
        }
        }}>Add to Cart</button>
    </div>
  )
}

export default ProductItem