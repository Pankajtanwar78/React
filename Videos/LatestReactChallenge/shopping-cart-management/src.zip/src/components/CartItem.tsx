import { UseCart } from "../context/CartProvider";
import { Cart } from "../data/initialData"

type CartItemProp = {
  itemInCart: Cart;
}

const CartItem = ({itemInCart}: CartItemProp) => {

  const cartContext = UseCart();

  return (
    <div style={{marginBottom: '10px', padding: '10px', border: '1px solid #fff', borderRadius: '4px', color: '#fff'}}>
      <div style={{marginBottom: '5px', fontWeight: 'bold'}}>
        {itemInCart.name}
      </div>
      <div style={{marginBottom: '5px'}}>{itemInCart.price}</div>
      <div style={{marginBottom: '5px'}}>{itemInCart.description}</div>
      <div>

        <label >Quantity: {itemInCart.quantity} {' '}</label>

        <button onClick={() => {
          cartContext.dispatch({
            type: 'INCREASE_QUANTITY',
            payload: {id: itemInCart.id}
          })
        }}>Increase</button>

        <button onClick={() => {
          cartContext.dispatch({
            type: 'DECREASE_QUANTITY',
            payload: {id: itemInCart.id}
          })
        }}>Decrease</button>

      </div>
      <button onClick={() => {
          cartContext.dispatch({
            type: 'REMOVE_FROM_CART',
            payload: {id: itemInCart.id}
          })
        }}>Remove</button>

    </div>
  )
}

export default CartItem