import React, { createContext, useContext, useReducer } from 'react'
import { initialUserAuth, UserAuth } from '../data/initialData'
import AuthReducer, { AuthAction } from '../reducer/AuthReducer';

type AuthContextProp = {
  authState: UserAuth;
  authDispatch: React.Dispatch<AuthAction>;
}

const AuthContext = createContext<AuthContextProp | undefined>(undefined)

type Props = {
  children: React.ReactNode;
}

const AuthProvider = ({children}: Props) => {
  const [authState, authDispatch] = useReducer(AuthReducer, initialUserAuth)
  return (
    <AuthContext.Provider value={ {authState, authDispatch }} >
      {children}
    </AuthContext.Provider>
  )
}

export function UseAuth() {
  const authContext = useContext(AuthContext);
  if(!authContext){
    throw new Error('UseAuth must be used inside AuthProvider')
  }
  return authContext;
}

export default AuthProvider