
import {Cart, Product} from '../data/initialData'

export type Action = 
    {type: 'ADD_TO_CART'; payload: Product}
  | {type: 'REMOVE_FROM_CART'; payload: {id: number}}
  | {type: 'INCREASE_QUANTITY'; payload: {id: number}}
  | {type: 'DECREASE_QUANTITY'; payload: {id: number}}
  | {type: 'CLEAR_CART'}

const CartReducer = (state: Cart[], action: Action): Cart[] => {
  switch (action.type) {
    case 'ADD_TO_CART': {
      if(state.find(item => item.id === action.payload.id)){
        return state.map(item => {
          if (item.id === action.payload.id){
            return {...item, quantity: item.quantity + 1}
          }
          else{
            return item;
          }
        });
      }
      else{
        return [...state, {...action.payload, quantity: 1}]
      }
    }
    case 'REMOVE_FROM_CART': {
      return state.filter(item => item.id !== action.payload.id);
    }
    case 'INCREASE_QUANTITY':{
      return state.map(item => {
        if (item.id === action.payload.id){
          return {...item, quantity: item.quantity + 1}
        }
        else{
          return item;
        }
      });
    }
    case 'DECREASE_QUANTITY': {

      if (state.find(item => item.id === action.payload.id)?.quantity === 1){
        return state.filter(item => item.id !== action.payload.id);
      }

      return state.map(item => {
        if (item.id === action.payload.id){
          return {...item, quantity: item.quantity - 1}
        }
        else{
          return item;
        }
      });
    }

    case 'CLEAR_CART':{
      return [];
    }
    default:
      return state;

  }
}

export default CartReducer;