import CartProvider from "./context/CartProvider"
import CartList from "./components/CartList"
import ProductList from "./components/ProductList"
import { initialProducts } from "./data/initialData"
import AuthProvider from './context/AuthProvider'
import Login from "./components/Login"

function App() {

  return (
    <AuthProvider>
      <CartProvider>
        <Login />
        <div style={{display: 'flex', padding: '30px', backgroundColor: '#89a097', justifyContent: 'space-around'}}>
          <ProductList products={initialProducts} />
          <CartList/>
        </div>
      </CartProvider>
    </AuthProvider>
  )
}

export default App
