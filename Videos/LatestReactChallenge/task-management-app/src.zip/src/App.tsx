import TaskManagement from "./components/TaskManagement"
import TasksPropHelper from "./components/UseTasks"
function App() {
  
  return <TasksPropHelper>
    <TaskManagement/>
  </TasksPropHelper>
  
}

export default App
